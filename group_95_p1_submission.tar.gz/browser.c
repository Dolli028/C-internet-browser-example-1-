/* CSCI-4061 Fall 2022
 * Group Member #1: Adisesh Viruru virur002
 * Group Member #2: Peter Kang kang0269
 * Group Member #3: Hugh Dolliff Dolli028
 */

#include "wrapper.h"
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <gtk/gtk.h>

/* === PROVIDED CODE === */
// Function Definitions
void new_tab_created_cb(GtkButton *button, gpointer data);
int run_control();
int on_blacklist(char *uri);
int bad_format (char *uri);
void uri_entered_cb(GtkWidget* entry, gpointer data);
void init_blacklist (char *fname);

/* === PROVIDED CODE === */
// Global Definitions
#define MAX_TAB 100                 //Maximum number of tabs allowed
#define MAX_BAD 1000                //Maximum number of URL's in blacklist allowed
#define MAX_URL 100                 //Maximum char length of a url allowed

/* === STUDENTS IMPLEMENT=== */
// HINT: What globals might you want to declare?
char * user_url;
int blacklist_len=-1; //length of blacklist 
int tabs = -1;  //tab counter 
char blacklist[MAX_BAD][MAX_URL];  // for our blacklist 
/* === PROVIDED CODE === */
/*
 * Name:		          new_tab_created_cb
 *
 * Input arguments:	
 *      'button'      - whose click generated this callback
 *			'data'        - auxillary data passed along for handling
 *			                this event.
 *
 * Output arguments:   void
 * 
 * Description:        This is the callback function for the 'create_new_tab'
 *			               event which is generated when the user clicks the '+'
 *			               button in the controller-tab. The controller-tab
 *			               redirects the request to the parent (/router) process
 *			               which then creates a new child process for creating
 *			               and managing this new tab.
 */
// NO-OP for now
void new_tab_created_cb(GtkButton *button, gpointer data)
{}
 
/* === PROVIDED CODE === */
/*
 * Name:                run_control
 * Output arguments:    void
 * Function:            This function will make a CONTROLLER window and be blocked until the program terminates.
 */
int run_control()
{
  // (a) Init a browser_window object
	browser_window * b_window = NULL;

	// (b) Create controller window with callback function
	create_browser(CONTROLLER_TAB, 0, G_CALLBACK(new_tab_created_cb),
		       G_CALLBACK(uri_entered_cb), &b_window);

	// (c) enter the GTK infinite loop
	show_browser();
  tabs ++; 
	return 0;
}

/* === STUDENTS IMPLEMENT=== */
/* 
    Function: on_blacklist  --> "Check if the provided URI is in th blacklist"
    Input:    char* uri     --> "URI to check against the blacklist"
    Returns:  True  (1) if uri in blacklist
              False (0) if uri not in blacklist
    Hints:
            (a) File I/O
            (b) Handle case with and without "www." (see writeup for details)
            (c) How should you handle "http://" and "https://" ??
*/ 
int on_blacklist (char *uri) {
  const char * period = ".";
  char * token;
  char * holder;
  for (int j = 0; j<blacklist_len;j++){
    token = strtok(blacklist[j],period); //set token to everything before the first period 
    if((strstr(token,"www"))!=NULL){   //if statement for when token is www
      holder = blacklist[j]+4;      //holder to take everything after www.
      token = strtok(holder,period);  //set token to everything before the first period in our holder
      if(strstr(uri,token)!=NULL){   //see if our token is in what the user inputed 
        alert("blacklist");          //alert if what they entered is on the blacklist 
        return 1; 
      }
    }else{
      if(strstr(uri,token)!=NULL){   //used for when the web address does not have www. at the begining. 
      alert("blacklist");            // alert if the entered web address is on the black list 
      return 1;
    }
 
    }
  }
return 0; // return 0 if not on the black list
}

/* === STUDENTS IMPLEMENT=== */
/* 
    Function: bad_format    --> "Check for a badly formatted url string"
    Input:    char* uri     --> "URI to check if it is bad"
    Returns:  True  (1) if uri is badly formatted 
              False (0) if uri is well formatted
    Hints:
              (a) String checking for http:// or https://
*/
int bad_format (char *uri) {
  if((strncmp("https://",uri,8)==0)||(strncmp("http://",uri,7)==0)){ //uses string compare to see if the first 8 characters are https:// or the first seven are http:// 
    return 0;  // return 0 if we have a correct format 
  }
  alert("bad format");  // if its not one of the above send alert bad format
return 1;  //return 1 if we have a bad format
}
/* === STUDENTS IMPLEMENT=== */
/*
 * Name:                uri_entered_cb
 *
 * Input arguments:     
 *                      'entry'-address bar where the url was entered
 *			                'data'-auxiliary data sent along with the event
 *
 * Output arguments:     void
 * 
 * Function:             When the user hits the enter after entering the url
 *			                 in the address bar, 'activate' event is generated
 *			                 for the Widget Entry, for which 'uri_entered_cb'
 *			                 callback is called. Controller-tab captures this event
 *			                 and sends the browsing request to the router(/parent)
 *			                 process.
 * Hints:
 *                       (a) What happens if data is empty? No Url passed in? Handle that
 *                       (b) Get the URL from the GtkWidget (hint: look at wrapper.h)
 *                       (c) Print the URL you got, this is the intermediate submission
 *                       (d) Check for a bad url format THEN check if it is in the blacklist
 *                       (e) Check for number of tabs! Look at constraints section in lab
 *                       (f) Open the URL, this will need some 'forking' some 'execing' etc. 
 */
void uri_entered_cb(GtkWidget* entry, gpointer data)
{
user_url=get_entered_uri(entry);  // set user_url to what was entered 
printf("%s \n",user_url);  
if(bad_format(user_url)==1){  //call function bad_format to make sure its a web address 
  return;
}
if(on_blacklist(user_url)==1){ // call function on_blacklist to see if its on the black list 
  return;
}
if(tabs>=MAX_TAB-1){//check if we have too many tabs 
  
  alert("too many tabs");  // alert for when we try to open too many tabs 
  return;
}
  tabs++; // add 1 to tab count when we clear all of the previous checks
pid_t search;
search= fork();
if(search==-1){ // for when the fork fails 
    perror("fork failed");
      return ;
  }
  if(search==0){  // when the fork is successful 
    char stringtab[10];
    sprintf(stringtab,"%d",tabs);//convert tabs number to a string
    //printf("%s \n",stringtab);
    execl("render","render",stringtab,user_url,NULL);//call render
    perror("child failed to exec all_ids1");
    exit(0);
  }
  //STUDENTS IMPLEMENT
  return;
}


/* === STUDENTS IMPLEMENT=== */
/* 
    Function: init_blacklist --> "Open a passed in filepath to a blacklist of url's, read and parse into an array"
    Input:    char* fname    --> "file path to the blacklist file"
    Returns:  void
    Hints:
            (a) File I/O (fopen, fgets, etc.)
            (b) If we want this list of url's to be accessible elsewhere, where do we put the array?
*/
void init_blacklist (char *fname) {//done!
  FILE* fp;                   //file pointer 
  const char* mode = "r";     //write mode for fopen()
  fp =fopen(fname,mode);      // open file fname in read mode 
  if(fp == NULL){             //case for when file cant be opened 
    perror("ERROR OPENING FILE!\n");
    exit(EXIT_FAILURE);
  }
   while(!feof(fp)){           //while loop for when there is still text in the file   
    blacklist_len ++;
    fgets(blacklist[blacklist_len], MAX_URL, fp); // add the website adress to our array blacklist //THIS MIGHT BE THE PROBLEM FIGURE IT OUT
  }
  fclose(fp);   //close the file             
}

/* === STUDENTS IMPLEMENT=== */
/* 

    Function: main 
    Hints:
            (a) Check for a blacklist file as argument, fail if not there [PROVIDED]
            (b) Initialize the blacklist of url's
            (c) Create a controller process then run the controller
                (i)  What should controller do if it is exited? Look at writeup (KILL! WAIT!)
            (d) Parent should not exit until the controller process is done 
*/
int main(int argc, char **argv)
{
  char *listname=argv[1];//take the blacklist name from the arguement line
  //STUDENT IMPLEMENT
  // (a) Check arguments for blacklist, error and warn if no blacklist
  if (argc != 2) {
    fprintf (stderr, "browser <blacklist_file>\n");
    exit (0);
  }

init_blacklist(listname);//initialize black list 
pid_t controller;//controller fork
  controller=fork();
  if(controller==-1){
    perror("fork failed");
      return 1;
  }
  if(controller==0){//if controller process
    run_control();//run the controller method
    kill(0, SIGKILL);//if controler is closed makes sure that everyything else gets closed as well
  }
  wait(NULL);//wait till controller
  return 0;
}
